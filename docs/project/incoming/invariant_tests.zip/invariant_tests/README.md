# Fixed-seed invariant tests

These extra tests exercise unchanged snapshots of the four supplied modules. The snapshots are included so the run can be reproduced independently. To test newer versions, replace the snapshots or place the test files beside the modules in your existing test environment.

Use Python 3.12 with pytest and python-dateutil installed. Run from this folder:

```sh
python -m pytest -q
```

The tests use only standard-library input generation with random.Random(seed), plus pytest and the recurrence module's existing dependency. They do not read the clock, contact services, or write files. ZoneInfo requires system time zone data. The same inputs are reproducible for a given seed under Python 3.12; time zone behavior also depends on the installed time zone database.

## Coverage

- Free slots: seeds 4101–4103, 100 cases each. An independent minute-by-minute UTC model counts working and occupied time. It checks free plus occupied equals working minutes for each day, including daylight-saving transitions, partial-day windows, all-day entries, buffers, tentative policy, and overlapping entries. It also checks returned gaps, minimum-length filtering, and input order independence.
- Bills: seeds 5201–5203, 150 cases each. A whole half-open window must equal its two adjacent pieces, including all five rule kinds, anchors, adjustments, long holiday closures, unusual workweeks, and reminders outside the window. Reminder dates, sorting, uniqueness of scheduled dates, and adjusted business days are checked separately.
- Recurrence: seeds 6301–6303, 150 cases each. Daily, weekly, monthly, and yearly rules use COUNT or UNTIL, plus selected BYDAY, BYMONTHDAY, BYMONTH, and BYSETPOS combinations. Inputs include all-day and zoned events, exclusions, extra dates, moves, and cancellations. Results must be sorted by actual instant, overlap the half-open window, preserve event type, honor exclusions, and remain stable when collections are reordered. COUNT bounds apply before extra dates and overrides.
- Mail threads: seeds 7401–7403, 150 cases each, with six shuffles per case. Known references, parent links, unique or ambiguous subject matches, missing message IDs, participant overlap, and date limits are exercised. Candidate and participant reordering must preserve the key. Subject normalization must be idempotent. Candidate message IDs are unique: conflicting mappings are invalid input and are outside this permutation test.

Total: 1,650 generated cases across 12 parametrized pytest tests.

## Conventions

Intervals are half-open. Recurrences are selected by overlap, so a result may begin before the window; requiring every start to be inside would contradict the module's contract. Zero-duration occurrences must start inside the window. Dates use date ordering; timed results use UTC ordering.

Availability totals include gaps shorter than min_minutes. The test uses min_minutes=1 for a second call to check that all generated free time is represented; generated boundaries have minute precision. Blocking time means the union after buffers and clipping to working hours, not the sum of raw meeting durations. All-day blocking follows the supplied module's documented policy, including tentative and out-of-office entries.

Bill partitioning uses adjusted due dates, not scheduled dates or reminder dates. Distinct scheduled bills remain distinct even when adjustment gives them the same due date.

These are invariant checks, not a complete independent recurrence or thread-selection implementation. Passing does not establish every rule's semantic correctness. No failures were found in this run. Assertion messages include the seed, case number, and full generated inputs for reproduction.

Sources: supplied module docstrings; Python Standard Library documentation for random, datetime, and zoneinfo; python-dateutil recurrence documentation.
